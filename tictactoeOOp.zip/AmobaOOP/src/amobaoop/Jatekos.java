/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amobaoop;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Norbert Szilagyi
 */
public class Jatekos extends Tabla{

    private String jel;

    public Jatekos(String jel) {
        this.jel = jel;
    }
  
    

    public void lepesKer() {
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Kerem a(z) '" + jel+ "' jatekos lepeset: ");
      
        
        
      
    }
    public void lepes(String aktJatekos) {

        int sor;
        int oszlop;

        do {
            Scanner sc = new Scanner(System.in);
            String lepes=sc.nextLine();
            
            String l1 = lepes.substring(0, 1);
            String l2 = lepes.substring(1);
            
            sor = -1;
            switch (l1) {
                case "A":
                    sor = 0;
                    break;
                case "B":
                    sor = 1;
                    break;
                case "C":
                    sor = 2;
                    break;

            }
            oszlop = -1;
            switch (l2) {
                case "1":
                    oszlop = 0;
                    break;
                case "2":
                    oszlop = 1;
                    break;
                case "3":
                    oszlop = 2;
                    break;
            }
        } while (sor < 0 || oszlop < 0 || !tabla[sor][oszlop].equals(" "));

        if (tabla[sor][oszlop].equals(" ")) {
            tabla[sor][oszlop] = aktJatekos;

        }

        tablaRajzol();

    }

    public Jatekos() {
    }

    public String getJel() {
        return jel;
    }

    public void setJel(String jel) {
        this.jel = jel;
    }

    @Override
    public String toString() {
        return jel;
    }

    
   

    
    
}
