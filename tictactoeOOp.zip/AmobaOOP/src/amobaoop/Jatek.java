/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amobaoop;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Norbert Szilagyi
 */
public class Jatek {

    public static String jatekosKezd(Jatekos jatekos1, Jatekos jatekos2) {

        String aktJatekos;
        String aktJatekos2;
        System.out.print("Fej vagy iras? : ");
        while (true) {
            int szamVeletlen;
            Scanner sc = new Scanner(System.in);
            aktJatekos2 = sc.nextLine();
            Random ran = new Random();
            szamVeletlen = ran.nextInt(10);

            if (aktJatekos2.equals("fej")) {
                aktJatekos = jatekos1.getJel();
                System.out.println("Fej az eredmeny ha a generalt szam nagyobb 5-nel es\n"
                        + "iras ha a generalt szam kissebb 6-nal.\nA generalt szam: " + szamVeletlen);

                if (szamVeletlen > 5) {
                    System.out.println("Jatekos kezd!");
                } else {
                    aktJatekos = jatekos2.getJel();
                    System.out.println("Computer fog kezdeni!");
                }
                break;
            }
            if (aktJatekos2.equals("iras")) {
                aktJatekos = jatekos2.getJel();
                System.out.println("Iras az eredmeny ha a generalt szam kissebb 6-nel es\n"
                        + "fej ha a generalt szam nagyobb 5-nel.\nA generalt szam: " + szamVeletlen);

                if (szamVeletlen < 6) {
                    System.out.println("Computer kezd!");
                } else {
                    aktJatekos = jatekos1.getJel();
                    System.out.println("Jatekos fog kezdeni!");
                }
                break;
            } else {
                System.out.print("Rossz valasz, valassz ujra! : ");
            }
        }
        return aktJatekos;

    }

    public static void main(String[] args) {

        Tabla tabla = new Tabla();
        Jatekos jatekos1 = new Jatekos("X");
        Cpu jatekos2 = new Cpu("O");

        while (tabla.eredmeny() == true) {
        String aktJatekos = jatekos1.getJel();

            System.out.println("Kerem a(z) " + aktJatekos + " lepeset: ");
            tabla.lepesJatekos(aktJatekos);
            
            if (aktJatekos == jatekos1.getJel()) {
                aktJatekos = jatekos2.getJel();
            } else {
                aktJatekos = jatekos1.getJel();
            }
           
            tabla.lepesCpu(aktJatekos);
            if (tabla.eredmeny() == false && tabla.isDontetlen() == false) {
                if(!aktJatekos.equals(jatekos1.getJel())){
                    System.out.println("Nyert a Jatekos");
                } else if(aktJatekos.equals(jatekos2.getJel())){
                    System.out.println("Nyert a Cpu");
                    
                }
            }

            if (tabla.isDontetlen() == true) {
                System.out.println("Vege, a jatek dontetlen");
            } 
            
            
        }

    }

}
