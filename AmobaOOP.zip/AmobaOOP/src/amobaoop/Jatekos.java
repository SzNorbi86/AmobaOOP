/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amobaoop;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Norbert Szilagyi
 */
public class Jatekos {

    private String jel;

    public Jatekos(String jel) {
        this.jel = jel;
    }
  
    

    public void lepesKer() {
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Kerem a(z) '" + jel+ "' jatekos lepeset: ");
      
        
        
      
    }
    

    public Jatekos() {
    }

    public String getJel() {
        return jel;
    }

    public void setJel(String jel) {
        this.jel = jel;
    }

    @Override
    public String toString() {
        return jel;
    }

    
   

    
    
}
