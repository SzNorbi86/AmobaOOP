/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amobaoop;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Norbert Szilagyi
 */
public class Jatek {

    public static Jatekos jatekosKezd(Jatekos jatekos1, Jatekos jatekos2) {

        Jatekos aktJatekos;
        String aktJatekos2;
        System.out.print("Fej vagy iras? : ");
        while (true) {
            int szamVeletlen;
            Scanner sc = new Scanner(System.in);
            aktJatekos2 = sc.nextLine();
            Random ran = new Random();
            szamVeletlen = ran.nextInt(10);

            if (aktJatekos2.equals("fej")) {
                aktJatekos = jatekos1;
                System.out.println("Fej az eredmeny ha a generalt szam nagyobb 5-nel es\n"
                        + "iras ha a generalt szam kissebb 6-nal.\nA generalt szam: " + szamVeletlen);

                if (szamVeletlen > 5) {
                    System.out.println("Jatekos kezd!");
                } else {
                    aktJatekos = jatekos2;
                    System.out.println("Computer fog kezdeni!");
                }
                break;
            }
            if (aktJatekos2.equals("iras")) {
                aktJatekos = jatekos2;
                System.out.println("Iras az eredmeny ha a generalt szam kissebb 6-nel es\n"
                        + "fej ha a generalt szam nagyobb 5-nel.\nA generalt szam: " + szamVeletlen);

                if (szamVeletlen < 6) {
                    System.out.println("Computer kezd!");
                } else {
                    aktJatekos = jatekos1;
                    System.out.println("Jatekos fog kezdeni!");
                }
                break;
            } else {
                System.out.print("Rossz valasz, valassz ujra! : ");
            }
        }
        return aktJatekos;

    }


    public static void main(String[] args) {

        Tabla tabla = new Tabla();
        Jatekos jatekos1 = new Jatekos("X");
        Jatekos jatekos2 = new Jatekos("O");
        Jatekos aktJatekos = jatekosKezd(jatekos1, jatekos2);

        while (tabla.eredmeny() == true ) {

            aktJatekos.lepesKer();
            tabla.lepes(aktJatekos);
            
             if (tabla.eredmeny()== false && tabla.isDontetlen()==false) {
              System.out.println("Vege nyert a(z) "+ aktJatekos.getJel()+ " jatekos");

            }

            if (tabla.isDontetlen()==true){
                System.out.println("Vege, a jatek dontetlen");
            }
            
         
            if (aktJatekos == jatekos1) {
                aktJatekos = jatekos2;
            } else {
                aktJatekos = jatekos1;

            }
        
    
        }
            
    }

}
